ZYYY — CLEAN JAPANESE MINIMALIST
=================================
Isi:
- index.html: website toko online
- images/: 6 gambar produk yang diberikan

Coba di laptop:
1. Ekstrak ZIP.
2. Buka folder hasil ekstrak.
3. Klik dua kali index.html.

Upload ke GitHub Pages:
1. Upload index.html DAN folder images ke root repository.
2. Buka Settings > Pages.
3. Pilih Deploy from a branch, branch main, folder /(root), lalu Save.

Fitur aktif:
- Navigasi halaman dan tombol pencarian.
- Filter kategori, pencarian, urut harga.
- Keranjang: tambah, kurangi jumlah, hapus.
- Checkout menyusun ringkasan pesanan dan membuka WhatsApp.
- Tautan WhatsApp, Instagram, email dapat diklik.

Nomor WhatsApp: 085607478295
Instagram: @royhan__11
Email: hanzzzz627@gmail.com
Harga produk dimulai Rp150.000. Konfirmasi stok, ukuran dan ongkir melalui WhatsApp.
